from flask import Flask, render_template, request, jsonify
import json
import os
import numpy as np
import torch
from sentence_transformers import SentenceTransformer, util
from transformers import pipeline
import openai
from dotenv import load_dotenv

# Load environment variables (for OpenAI API Key)
load_dotenv()
OPENAI_API_KEY = os.getenv("")

# Initialize Flask app
app = Flask(__name__, template_folder="templates", static_folder="static")

# Load the BERT-based model for embeddings
bert_model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")

# Load the Q&A model 
qa_pipeline = pipeline("question-answering", model="deepset/roberta-base-squad2")

DATA_FILE = "chatbot_data.json"

def load_data():
    """Load chatbot data from a JSON file."""
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r") as file:
            return json.load(file)
    return {"questions": [], "answers": []}

# Load existing chatbot knowledge
data = load_data()
questions = data["questions"]
answers = data["answers"]

# Compute embeddings for stored questions
if questions:
    question_embeddings = bert_model.encode(questions, convert_to_tensor=True)
else:
    question_embeddings = None

def chatbot_response(user_input):
    """Finds the best matching response using BERT embeddings, falls back to Q&A model, then GPT-4 API."""
    
    # BERT similarity matching
    if questions:
        input_embedding = bert_model.encode(user_input, convert_to_tensor=True)
        similarities = util.pytorch_cos_sim(input_embedding, question_embeddings)[0]
        best_match_idx = torch.argmax(similarities).item()
        confidence = similarities[best_match_idx].item()

        if confidence > 0.5:
            return answers[best_match_idx]

    # Step 2: Try answering using the fine-tuned Q&A model


    # Step 3: Use API as the last fallback
    return "I can't Understand,please ask anything else"
def generate_gpt_response(user_input):
    try:
        model = genai.GenerativeModel("gemini-pro")  # Using Gemini Pro Model
        response = model.generate_content(user_input)
        return response.text.strip() if response.text else "I'm not sure, can you clarify?"
    except Exception as e:
        print("Error with Gemini API:", str(e))
        return "I'm having trouble understanding. Please try again."
    

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def get_response():
    """Handles user chat requests."""
    data = request.get_json()
    user_input = data.get("message", "")

    if not user_input:
        return jsonify({"response": "I didn't get that. Can you repeat?"})

    response = chatbot_response(user_input)
    return jsonify({"response": response})

if __name__ == "__main__":
    app.run(debug=True)
