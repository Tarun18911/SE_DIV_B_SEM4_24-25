from flask import Flask, render_template, request, redirect, url_for, session, jsonify
import json
import os
import numpy as np
import torch
from sentence_transformers import SentenceTransformer, util
from transformers import pipeline
from dotenv import load_dotenv
import mysql.connector
import google.generativeai as genai
import secrets
from werkzeug.security import generate_password_hash, check_password_hash

# Load environment variables
load_dotenv()
GEMINI_API_KEY = os.getenv("AIzaSyAeVfblsnGvJxRJq4NQeNx82l8pGhs2pTM")
genai.configure(api_key=GEMINI_API_KEY)

sec = secrets.token_hex(16)
app = Flask(__name__, template_folder="templates", static_folder="static")
app.secret_key = sec

bert_model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
qa_pipeline = pipeline("question-answering", model="deepset/roberta-base-squad2")

DATA_FILE = "chatbot_data.json"

def load_data():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r") as file:
            return json.load(file)
    return {"questions": [], "answers": []}

data = load_data()
questions = data["questions"]
answers = data["answers"]
question_embeddings = (
    bert_model.encode(questions, convert_to_tensor=True) if questions else None
)

try:
    db = mysql.connector.connect(
        host="localhost",
        user="root",
        password="Himysql#123",
        database="chatbot"
    )
    cursor = db.cursor()
    print("✅ MySQL connected successfully.")
except Exception as e:
    print("❌ MySQL connection failed:", e)
    db = None
    cursor = None

def get_next_conversation_id():
    cursor.execute("SELECT MAX(conversation_id) FROM chat_logs")
    result = cursor.fetchone()[0]
    return (result or 0) + 1

def chatbot_response(user_input):
    if questions and question_embeddings is not None:
        input_embedding = bert_model.encode(user_input, convert_to_tensor=True)
        similarities = util.pytorch_cos_sim(input_embedding, question_embeddings)[0]
        best_match_idx = torch.argmax(similarities).item()
        confidence = similarities[best_match_idx].item()
        if confidence > 0.5:
            return answers[best_match_idx]
    return generate_gpt_response(user_input)

def generate_gpt_response(user_input):
    try:
        model = genai.GenerativeModel("gemini-pro")
        response = model.generate_content(user_input)
        return response.text.strip() if response.text else "I'm not sure, can you clarify?"
    except Exception as e:
        print("❌ Error with Gemini API:", str(e))
        return "I'm having trouble understanding. Please try again."

@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        cursor.execute("SELECT * FROM users WHERE username=%s", (username,))
        user = cursor.fetchone()

        if user and check_password_hash(user[2], password):
            session["user_id"] = user[0]
            session["username"] = user[1]
            return redirect(url_for("chat"))
        else:
            return render_template("login.html", error="Invalid credentials.")
    return render_template("login.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        confirm_password = request.form["confirm_password"]

        if password != confirm_password:
            return render_template("register.html", error="Passwords do not match.")

        cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
        if cursor.fetchone():
            return render_template("register.html", error="Username already exists.")

        hashed_password = generate_password_hash(password)
        cursor.execute("INSERT INTO users (username, password) VALUES (%s, %s)", (username, hashed_password))
        db.commit()
        return redirect(url_for("login"))

    return render_template("register.html")

@app.route("/chat", methods=["GET"])
def chat():
    if "user_id" not in session:
        return redirect(url_for("login"))
    return render_template("index.html", username=session["username"])

@app.route("/chat", methods=["POST"])
def get_response():
    data = request.get_json()
    user_input = data.get("message", "").strip()

    if not user_input:
        return jsonify({"response": "I didn't get that. Can you repeat?"})

    response = chatbot_response(user_input)

    if db and cursor:
        try:
            conversation_id = session.get("conversation_id", 1)
            cursor.execute(
                "INSERT INTO chat_logs (user_message, bot_response, conversation_id) VALUES (%s, %s, %s)",
                (user_input, response, conversation_id)
            )
            db.commit()
        except Exception as e:
            print("❌ Database insert error:", e)

    return jsonify({"response": response})

@app.route("/history/<int:cid>", methods=["GET"])
def load_conversation(cid):
    cursor.execute(
        "SELECT user_message, bot_response FROM chat_logs WHERE conversation_id = %s",
        (cid,)
    )
    rows = cursor.fetchall()
    return jsonify({"conversation": rows})

@app.route("/conversations")
def get_conversation_count():
    cursor.execute("SELECT MAX(conversation_id) FROM chat_logs")
    result = cursor.fetchone()[0]
    return jsonify({"count": result or 0})

@app.route("/new_conversation", methods=["POST"])
def new_conversation():
    session["conversation_id"] = get_next_conversation_id()
    return jsonify({"conversation_id": session["conversation_id"]})

@app.route("/delete_conversation/<int:cid>", methods=["DELETE"])
def delete_conversation(cid):
    if db and cursor:
        try:
            cursor.execute("DELETE FROM chat_logs WHERE conversation_id = %s", (cid,))
            db.commit()
            return jsonify({"message": f"Conversation {cid} deleted successfully."}), 200
        except Exception as e:
            print(f"❌ Error deleting conversation {cid}: {e}")
            return jsonify({"message": "Failed to delete conversation."}), 500
    return jsonify({"message": "Database connection error."}), 500

@app.route("/rename_conversation", methods=["POST"])
def rename_conversation():
    data = request.get_json()
    conversation_id = data.get("conversation_id")
    new_name = data.get("new_name")

    if db and cursor and conversation_id and new_name:
        try:
            cursor.execute(
                "UPDATE chat_logs SET conversation_name = %s WHERE conversation_id = %s",
                (new_name, conversation_id)
            )
            db.commit()
            return jsonify({"message": f"Conversation {conversation_id} renamed to '{new_name}'."}), 200
        except Exception as e:
            print(f"❌ Error renaming conversation {conversation_id}: {e}")
            return jsonify({"message": "Failed to rename conversation."}), 500
    return jsonify({"message": "Invalid request or database error."}), 400

if __name__ == "__main__":
    app.run(debug=True)
